eval "$(starship init zsh)"
