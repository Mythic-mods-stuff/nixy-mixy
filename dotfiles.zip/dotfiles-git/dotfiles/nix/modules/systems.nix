{ inputs, ... }:
{
  flake-file.inputs.systems = {
    url = "path:./flake.systems.nix";
    flake = false;
  };
  systems = import inputs.systems;
}
