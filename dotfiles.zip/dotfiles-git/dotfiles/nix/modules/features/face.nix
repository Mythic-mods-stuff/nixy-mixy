{
  den.aspects.face = { user, ... }: {
    nixos = { config, ... }: {
      systemd.tmpfiles.rules =
        let
          username = user.userName;
        in
        [
          "f+ /var/lib/AccountsService/users/${username}  0600 root root - [User]\\nIcon=/var/lib/AccountsService/icons/${username}\\n"
          "L+ /var/lib/AccountsService/icons/${username}  - - - - ${
            config.hjem.users.${username}.files.".face.icon".source
          }"
        ];
    };
    hjem = {
      files.".face.icon".source = ./logo.png;
    };
  };
}
