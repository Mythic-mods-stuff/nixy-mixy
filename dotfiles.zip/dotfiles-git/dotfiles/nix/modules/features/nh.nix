{
  den.aspects.nh.nixos = {
    programs.nh = {
      enable = true;
      flake = "/home/ruhtra/dotfiles/nix";
      clean = {
        enable = true;
        extraArgs = "--keep 20 --keep-since 10d";
        dates = "hourly";
      };
    };
  };
}
