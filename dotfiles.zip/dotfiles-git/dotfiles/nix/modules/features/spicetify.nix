{ inputs, ... }: {
  flake-file.inputs.spicetify-nix = {
    url = "github:gerg-l/spicetify-nix";
    inputs = {
      nixpkgs.follows = "nixpkgs";
      systems.follows = "systems";
    };
  };
  den.aspects.spicetify.nixos = { pkgs, ... }: {
    imports = [
      inputs.spicetify-nix.nixosModules.default
    ];
    my.allowedUnfreePackageNames = [ "spotify" ];
    programs.spicetify =
      let
        spicePkgs = inputs.spicetify-nix.legacyPackages.${pkgs.stdenv.hostPlatform.system};
      in
      {
        enable = true;
        enabledExtensions = builtins.attrValues {
          inherit (spicePkgs.extensions)
            fullAppDisplay
            keyboardShortcut
            adblock
            privateSession
            focusMode
            popupLyrics
            ;
        };
        theme = spicePkgs.themes.catppuccin;
        colorScheme = "mocha";
      };
  };
}
