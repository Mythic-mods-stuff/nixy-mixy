{ self, ... }:
{
  den.aspects.homelab = {
    _.dns.nixos = {
      networking.nameservers = [ "192.168.43.0" ];
    };
    _.webdav = { user, ... }: {
      nixos = {
        systemd = {
          mounts = [
            {
              enable = true;
              description = "Webdav mount point for webdav.home.arpa";
              after = [ "network-online.target" ];
              wants = [ "network-online.target" ];

              what = "https://webdav.home.arpa/files";
              where = "/home/${user.userName}/Documents/webdav";
              options = "x-systemd.automount,uid=1000,gid=100,file_mode=0644,dir_mode=0775";
              type = "davfs";
              mountConfig.TimeoutSec = 15;
            }
          ];
        };
        age.secrets.webdav = {
          file = "${self.outPath}/secrets/webdav.age";
          owner = "root";
          mode = "0600";
          path = "/etc/davfs2/secrets";
        };
      };
    };
    _.tls.nixos = { self', ... }: {
      security.pki.certificateFiles = [
        self'.packages.homelab-ca-crt
      ];
    };
    _.secrets = {
      nixos = {
        age.secrets = {
          kubeconfig = {
            file = "${self.outPath}/secrets/kubeconfig.age";
            owner = "ruhtra";
          };
          talosconfig = {
            file = "${self.outPath}/secrets/talosconfig.age";
            owner = "ruhtra";
          };
        };
      };
      hjem =
        { osConfig, ... }:
        {
          files = {
            ".kube/config".source = osConfig.age.secrets.kubeconfig.path;
            ".talos/config".source = osConfig.age.secrets.talosconfig.path;
          };
        };
    };
    _.wireguard.nixos =
      { config, lib, ... }:
      {
        age.secrets = {
          wireguard-key = {
            file = "${self.outPath}/secrets/wireguard-key.age";
            mode = "640";
            owner = "systemd-network";
            group = "systemd-network";
          };
          wireguard-psk = {
            file = "${self.outPath}/secrets/wireguard-psk.age";
            mode = "640";
            owner = "systemd-network";
            group = "systemd-network";
          };
        };

        systemd.services.wg-quick-wg0 = {
          enable = true;
          wantedBy = lib.mkForce [ ];
        };

        networking = {
          wg-quick.interfaces.wg0 = {
            address = [
              "192.168.42.201/23"
              "fdc5:b9df:39e9::201/64"
            ];
            privateKeyFile = config.age.secrets.wireguard-key.path;
            dns = [
              "192.168.43.0"
              "192.168.42.1"
              "fdc5:b9df:39e9::e72:74ff:fe37:9395"
            ];
            peers = [
              {
                publicKey = "b6sMMgchjQGp3zK7OMQdI4qX+9yQo7pCd8MrCfbvrAI=";
                allowedIPs = [
                  "192.168.42.0/23"
                  "0.0.0.0/0"
                  "fdc5:b9df:39e9::/64"
                  "::/0"
                ];
                endpoint = "appleptree.v6.rocks:57022";
                presharedKeyFile = config.age.secrets.wireguard-psk.path;
                persistentKeepalive = 25;
              }
            ];
          };
          firewall.allowedUDPPorts = [ 51820 ];
        };
      };
  };
}
