{
  den.aspects.ddc.nixos =
    { pkgs, ... }:
    {
      hardware.i2c.enable = true;
      boot.kernelModules = [ "i2c-dev" ];
      users.groups.i2c.members = [ "ruhtra" ];
      users.users.ruhtra.packages = [ pkgs.ddcutil ];
      services.udev.packages = [ pkgs.ddcutil ];
    };
}
