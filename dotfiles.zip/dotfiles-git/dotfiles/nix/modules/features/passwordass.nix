{
  den.aspects.passwordass.hjem =
    { inputs', ... }:
    {
      packages = [
        (inputs'.custom-packages.packages.passwordass.override {
          useRage = false;
        })
      ];
    };
}
