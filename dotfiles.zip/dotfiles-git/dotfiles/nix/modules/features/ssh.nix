{ self, ... }:
{
  den.aspects.ssh = {
    hjem =
      { osConfig, ... }:
      {
        files = {
          ".ssh/id_ed25519.pub".source = osConfig.age.secrets.ruhtra-id_ed25519-pub.path;
          ".ssh/id_ed25519".source = osConfig.age.secrets.ruhtra-id_ed25519.path;
          ".radicle/keys/radicle.pub".source = osConfig.age.secrets.radicle-public-key.path;
          ".radicle/keys/radicle".source = osConfig.age.secrets.radicle-private-key.path;
        };
      };
    nixos = { pkgs, ... }: {
      programs.ssh = {
        startAgent = true;
        knownHostsFiles = [
          (pkgs.writeText "persistent.keys" ''
            git.private.coffee ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIH7Y9JgcIsiKlOw8v21VMefl6M+lqdhetKyabCQ4Cp/z
            git.private.coffee ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABgQCyCVkw05nA4YchaycPU0FEI+1WJ9ppTfDPMErSm4MFv3tprmN0nTu8tGuHudnRPKBRsGaNwBdsoyc+ZbazpwpO3yXcq0QSeEqvSSn1Oi3ydpNy5TPQgyU/LRKWA2Nu5L93tMBGbj13xAXCWLVbluwMpNcANfXpHnJzea+FTOZeATpxql22mBjyDyitPA6U9evGiHEWKE+z8S5lO+msTLeRAnnC7Y2qlsQ4i55RaMxT7AsRfvmDZYvmQuEcID806Rwv9XPFe8nIzuRsz9PGypOQcTdu2XmXLmodhcFHx14nbVgu3KvrjfU4XA9tyFfU24Hlf2ePVQwsJQbYL3yxkTHpgJiZgWtCnA2PGMJJDP9lRTOwSpxOppDuspoOpJdtJuKu0XKVybiBLHhfwNWMJ9bwfvpBuu5v+Z1XCN4u1EhahgyWWdXctWIV2Hi1gSGVvKOnaln2XQP12MkVRee46gDzgqNFw+Xx1NKCgGsC5pC5Uczel1ftuWifjeJZfhoqC/k=
            git.private.coffee ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBBs6RGYTzJS+ExcM17yUD4F0dD4qw1rx+mpNe2RLl1DvFbj5h0KG2dFdGafvOpL3IK1eGt4m9enBvhFrhxLQU1I=
            forgejo.home.arpa ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAACAQDjrT7HWEP2O70y3f0golkX73APNRGPGrmzCkYH3TxUJxR47SEtzKJ4KjktdkNTNfOxDYIQ2CIkiK3JPzieRnJxHB3RDRBnJ1Qkq0r7wg/ONhhkOJeiOi+CoDU2RUDpmh/yCTVIWkBQIybl2O+am7vsTspqFPtbTWYFHDZp5WsRIOlyrUNLhqcxT4obf3rc/oZvEFm8iEgKpHdrpYD04gzsulr9B2sydCxeaE8A+UT9tNPggAJiO/3ypFgtVM1Vw24kavPKzUt+KidRV6ivvcKQKIo48hARm7uuEazcZ53AFVYK3Qwsbg9u1co9RBQ6IawD6honJhEJ+AsjCjo7ry5YlFPQJ5oCnre1uslxj0Zgk9zAtOFbWadIvh1tI+SiUE5s8Jes9/o6m+M0m9LcoQbzOBvLwvdTMk15/Xed37tW/Nhd2NQIuERzwCZbtFh60Y65W+25KvmaoZBl0CvBICqNVJIYSBlm9yLTrk9Vi8ADcIYfhsNrONCPQPYoLpG694UWhlVYjnWqrL/Bnq2nNRrBKgG10IDg9oc83j0RnH1OGwBasrxfNiiDf3nMNYYp9XoF25NcEU4FMKvI6fJxoVt05VvSpu34uYHm+Rc6w9Mgz2dGZOXADh0t1EffMPVHQNoBnOCu1/mT11nbpRMe+kR1n3miaGqwSkPH7Fo4nuzMaw==
            framagit.org ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIFSgY54eVXNl+dIlpjkSiIXNaj+V734R9DAw3uUY2YFD
            framagit.org ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDqvZUWt8PfOYU1cq7HJxVzvVF+qoQ66DQgSXstKzjYlVE9PoplZhzWA3SfMd3rqQMdhbGBE/Z7r8zIEel4WEDgygDmBlSFc+aqnH6Z1IqAu7kC+4fpcufaIu1WbG/b5eiyERwQdEjG9jtJ3fi12k4L/AgKVoWJnXwsWawxc3Iqjl5FczBjslySt9suYtxGNuJnREksg3Eg3S/3C1yyiUjrPC84Pr8W0ptklV0LpCh14USv//Q7W2p0Mlkjm21qj4quz1VitSL9PV9Qh5bnGMQH9ckq4bbd5TQMYSHLF8lMt7nWAjRnPN377gS5CmXoZK3e/ml95CHAFjPDPN5BVSOR
            framagit.org ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBMwVAxRFizaWBgaKvpwwBJZumDqaxXuucDvFsYhPZXxoUmvGG/+dQB90vC4rJRzZn/cFN5USQCaEVTWZQzqHJGg=
            codeberg.org ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIVIC02vnjFyL+I4RHfvIGNtOgJMe769VTF1VR4EB3ZB
            github.com ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIOMqqnkVzrm0SdG6UOoqKLsabgH5C9okWi0dh2l9GKJl
            git.sr.ht ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIMZvRd4EtM7R+IHVMWmDkVU3VLQTSwQDSAvW0t2Tkj60
            git.sr.ht ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDZ+l/lvYmaeOAPeijHL8d4794Am0MOvmXPyvHTtrqvgmvCJB8pen/qkQX2S1fgl9VkMGSNxbp7NF7HmKgs5ajTGV9mB5A5zq+161lcp5+f1qmn3Dp1MWKp/AzejWXKW+dwPBd3kkudDBA1fa3uK6g1gK5nLw3qcuv/V4emX9zv3P2ZNlq9XRvBxGY2KzaCyCXVkL48RVTTJJnYbVdRuq8/jQkDRA8lHvGvKI+jqnljmZi2aIrK9OGT2gkCtfyTw2GvNDV6aZ0bEza7nDLU/I+xmByAOO79R1Uk4EYCvSc1WXDZqhiuO2sZRmVxa0pQSBDn1DB3rpvqPYW+UvKB3SOz
            git.sr.ht ecdsa-sha2-nistp256 AAAAE2VjZHNhLXNoYTItbmlzdHAyNTYAAAAIbmlzdHAyNTYAAABBBCj6y+cJlqK3BHZRLZuM+KP2zGPrh4H66DacfliU1E2DHAd1GGwF4g1jwu3L8gOZUTIvUptqWTkmglpYhFp4Iy4=
          '')
        ];
      };
      services.gnome.gcr-ssh-agent.enable = false; # If true conflicts
      age.secrets = {
        radicle-private-key = {
          file = "${self.outPath}/secrets/radicle.age";
          owner = "ruhtra";
        };
        radicle-public-key = {
          file = "${self.outPath}/secrets/radicle.pub.age";
          owner = "ruhtra";
        };
        ruhtra-id_ed25519 = {
          file = "${self.outPath}/secrets/ruhtra-id_ed25519.age";
          owner = "ruhtra";
        };
        ruhtra-id_ed25519-pub = {
          file = "${self.outPath}/secrets/ruhtra-id_ed25519.pub.age";
          owner = "ruhtra";
        };
      };
    };
  };
}
