{
  den.aspects.qmk = {
    hjem = { pkgs, ... }: {
      packages = [
        pkgs.qmk
        pkgs.qmk_hid
        pkgs.vial
        pkgs.dos2unix
      ];
    };
    _.to-hosts = {
      nixos = { pkgs, ... }: {
        services.udev.packages = [
          pkgs.qmk
          pkgs.qmk-udev-rules
          pkgs.qmk_hid
          pkgs.vial
        ];
      };
    };
  };
}
