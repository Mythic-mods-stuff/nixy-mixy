{ inputs, ... }:
{
  den.aspects.kmscon.nixos =
    { pkgs, lib, ... }:
    {
      boot.kernelParams = [
        "vt.default_red=30,243,166,249,137,245,148,186,88,243,166,249,137,245,148,166"
        "vt.default_grn=30,139,227,226,180,194,226,194,91,139,227,226,180,194,226,173"
        "vt.default_blu=46,168,161,175,250,231,213,222,112,168,161,175,250,231,213,200"
      ];
      services = {
        gpm.enable = true;
        kmscon = {
          enable = true;
          useXkbConfig = true;
          config = # Copied from stylix
            let
              palette = builtins.mapAttrs (
                name: value:
                lib.pipe value [
                  (builtins.split "([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})")
                  (list: builtins.elemAt list 1)
                  (map lib.fromHexString)
                  (map toString)
                  (lib.concatStringsSep ",")
                ]
              ) inputs.basix.schemeData.base16.catppuccin-mocha.palette;
            in
            {
              font-name = "MonaspiceXe Nerd Font";

              palette = "custom";

              palette-black = palette.base00;
              palette-red = palette.base08;
              palette-green = palette.base0B;
              palette-yellow = palette.base0A;
              palette-blue = palette.base0D;
              palette-magenta = palette.base0E;
              palette-cyan = palette.base0C;
              palette-light-grey = palette.base05;
              palette-dark-grey = palette.base03;
              palette-light-red = palette.base08;
              palette-light-green = palette.base0B;
              palette-light-yellow = palette.base0A;
              palette-light-blue = palette.base0D;
              palette-light-magenta = palette.base0E;
              palette-light-cyan = palette.base0C;
              palette-white = palette.base07;

              palette-background = palette.base00;
              palette-foreground = palette.base05;
            };
        };
      };
    };
}
