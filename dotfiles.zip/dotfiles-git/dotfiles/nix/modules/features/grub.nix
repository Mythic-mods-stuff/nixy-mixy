{
  den.aspects.grub.nixos =
    { pkgs, ... }:
    {
      boot.loader = {
        efi.canTouchEfiVariables = true;
        grub = {
          enable = true;
          devices = [ "nodev" ];
          efiSupport = true;
          useOSProber = true;
          extraEntries = ''
            menuentry "UEFI Firmware Settings" \$menuentry_id_option 'uefi-firmware' --class efi {
              fwsetup
            }
            menuentry "Shutdown" --class shutdown {
              halt
            }
            menuentry "Reboot" --class restart {
              reboot
            }
          '';
          theme = pkgs.catppuccin-grub;
          configurationLimit = 20;
        };
      };
    };
}
