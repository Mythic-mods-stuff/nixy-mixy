{
  den.aspects.crypttab.nixos = {
    environment.etc.crypttab = {
      mode = "0600";
      text = ''
        # <volume-name> <encrypted-device> [key-file] [options]
        crypted-banana-cake UUID=04694481-e007-4859-ac10-3b5fdf39fe76 - noauto
        crypted-starfruit-cake UUID=9b6ba1fb-2542-4ca2-aae0-fbcba45cf156 - noauto
      '';
    };
  };
}
