{ inputs, ... }:
{
  flake-file.inputs.impermanence = {
    url = "github:nix-community/impermanence";
    inputs = {
      nixpkgs.follows = "";
      home-manager.follows = "";
    };
  };
  den.aspects.impermanence = {
    nixos = {
      imports = [ inputs.impermanence.nixosModules.impermanence ];
      boot.initrd.systemd.services.recreate-root = {
        description = "Rolling over and creating new filesystem root";

        wantedBy = [ "initrd.target" ];
        requires = [ "initrd-root-device.target" ];
        after = [
          "initrd-root-device.target"
          "local-fs-pre.target"
        ];
        before = [
          "sysroot.mount"
          "create-needed-for-boot-dirs.service"
        ];

        unitConfig.defaultDependencies = "no";
        serviceConfig.Type = "oneshot";
        script = ''
          mkdir /btrfs_tmp
          mount /dev/mapper/pool-root /btrfs_tmp
          if [[ -e /btrfs_tmp/root ]]; then
            mkdir -p /btrfs_tmp/old_roots
            timestamp=$(date --date="@$(stat -c %Y /btrfs_tmp/root)" "+%Y-%m-%d_%H:%M:%S")
            mv /btrfs_tmp/root "/btrfs_tmp/old_roots/$timestamp"
          fi

          delete_subvolume_recursively() {
            IFS=$'\n'
            for i in $(btrfs subvolume list -o "$1" | cut -f 9- -d ' '); do
              delete_subvolume_recursively "/btrfs_tmp/$i"
            done
            btrfs subvolume delete "$1"
          }

          for i in $(find /btrfs_tmp/old_roots/ -maxdepth 1 -mtime +10); do
            delete_subvolume_recursively "$i"
          done

          btrfs subvolume create /btrfs_tmp/root
          umount /btrfs_tmp
        '';
      };
      environment.persistence."/persist" = {
        enable = true;
        hideMounts = true;
        directories = [
          "/var/log"
          "/var/lib/bluetooth"
          "/var/lib/nixos"
          "/var/lib/systemd/coredump"
          "/var/lib/iwd"
          "/var/lib/sbctl"
          "/var/lib/systemd/rfkill"
          # "/sys/class/backlight"
          {
            directory = "/var/lib/colord";
            user = "colord";
            group = "colord";
            mode = "u=rwx,g=rx,o=";
          }
        ];
        files = [
          "/etc/machine-id"
        ];
        users.ruhtra = {
          directories = [
            "dotfiles"
            "git"
            "Documents"
            # Passwords
            ".local/share/pa"
            # Doppler token
            ".doppler"
            # Atuin login and db
            ".local/share/atuin"
            # Bat theme cache
            ".cache/bat"
            # Direnv allows
            ".local/share/direnv/allow"
            # Radicle storage and node info
            ".radicle"
            # Zoxide db
            ".local/share/zoxide"
            # GnuPG keys (mainly noreply@github.com)
            {
              directory = ".gnupg";
              mode = "700";
            }
            # Iamb chats
            ".local/share/iamb/profiles/user"
            # Fratal chats & stuff
            ".local/share/fractal"
            ".local/share/keyrings"
            # Signal chats
            ".config/Signal"
            # Jrnl journals
            ".local/share/jrnl"
            # Cargo build cache
            ".cargo"
            # NB notebooks
            ".nb"
          ];
          files = [
            # Nushell history
            ".config/nushell/history.txt"
            # Zellij plugin permissions
            ".cache/zellij/permissions.kdl"
          ];
        };
      };
    };
    hjem =
      { pkgs, lib, ... }:
      {
        systemd.services.stow-config = {
          enable = true;
          after = [ "network.target" ];
          wantedBy = [ "default.target" ];
          description = "Symlink impure dotfiles";
          serviceConfig = {
            Type = "oneshot";
            ExecStart = "${lib.getExe' pkgs.stow "stow"} -d /home/ruhtra/dotfiles . -vv --no-folding";
          };
        };
      };
  };
}
