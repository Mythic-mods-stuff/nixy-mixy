{
  den.aspects.niri.nixos =
    {
      pkgs,
      self',
      lib,
      ...
    }:
    let
      mkSystemdWrapper = package: executablePath: {
        enable = true;
        wantedBy = [ "niri.service" ];
        partOf = [ "graphical-session.target" ];
        after = [ "graphical-session.target" ];
        requisite = [ "graphical-session.target" ];
        serviceConfig = {
          ExecStart =
            if executablePath == null then
              lib.getExe' package package.pname
            else
              "${package}/${executablePath}";
          Restart = "on-failure";
        };
        environment.GTK_THEME = "Adwaita:dark";
      };
    in
    {
      hardware.brillo.enable = true;
      environment.systemPackages = [
        pkgs.xwayland-satellite
        pkgs.xdg-desktop-portal-cosmic
        pkgs.xdg-desktop-portal-gnome
        pkgs.xdg-desktop-portal-gtk
      ];
      programs = {
        niri.enable = true;
        mango.enable = true;
        sway = {
          enable = true;
          wrapperFeatures.gtk = true;
          extraPackages = [
            pkgs.swaynotificationcenter
            pkgs.poweralertd
            pkgs.wlsunset
            pkgs.polkit_gnome
            pkgs.udiskie
            self'.packages.swayidle
            pkgs.wpaperd
          ];
        };
      };
      systemd.user.services = {
        swaync = mkSystemdWrapper pkgs.swaynotificationcenter "bin/swaync";
        poweralertd = mkSystemdWrapper pkgs.poweralertd null;
        wlsunset = mkSystemdWrapper pkgs.wlsunset "bin/wlsunset -t 3000 -T 3001";
        polkit-gnome = mkSystemdWrapper pkgs.polkit_gnome "libexec/polkit-gnome-authentication-agent-1";
        udiskie = mkSystemdWrapper pkgs.udiskie null;
        swayidle = mkSystemdWrapper self'.packages.swayidle null;
        wpaperd = mkSystemdWrapper pkgs.wpaperd null;
        foot-server = mkSystemdWrapper self'.packages.foot "bin/foot --server";
      };
    };
}
