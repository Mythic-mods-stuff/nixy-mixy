{
  den.aspects.autologin =
    { user, ... }:
    {
      nixos = {
        services = {
          displayManager.autoLogin = {
            enable = true;
            user = user.userName;
          };
          getty.autologinUser = user.userName;
        };
      };
    };
}
