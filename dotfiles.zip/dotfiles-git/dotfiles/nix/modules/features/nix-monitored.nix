{
  flake-file.inputs.nix-monitored = {
    url = "github:ners/nix-monitored";
    inputs.nixpkgs.follows = "nixpkgs";
  };
  den.aspects.nix-monitored.nixos =
    { inputs', ... }:
    {
      nix.package = inputs'.nix-monitored.packages.default.override {
        withNotify = true;
      };
    };
}
