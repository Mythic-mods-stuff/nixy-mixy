{
  den.aspects.fonts.nixos =
    { pkgs, ... }:
    {
      fonts = {
        packages = [
          pkgs.monocraft
          pkgs.miracode
          pkgs.monaspace
          pkgs.monoid
          pkgs.iosevka
          pkgs.commit-mono
          pkgs.victor-mono
          pkgs.recursive
          pkgs.fira-code
          pkgs.sudo-font
          pkgs.nerd-fonts.monaspace
          pkgs.nerd-fonts.symbols-only
          pkgs.nerd-fonts.victor-mono
          pkgs.nerd-fonts.recursive-mono
          pkgs.jost
          pkgs.comfortaa
          pkgs.texlivePackages.josefin
          pkgs.ocr-a
          pkgs.google-fonts
        ];
        fontconfig.defaultFonts = {
          serif = [ "EB Garamond" ];
          sansSerif = [ "Montserrat" ];
          monospace = [ "MonaspiceXe Nerd Font" ];
        };
      };
    };
}
