{
  den.aspects.packages._.cli.hjem =
    {
      pkgs,
      self',
      inputs',
      ...
    }:
    {
      packages = [
        pkgs.fd
        pkgs.gcc
        pkgs.mold
        pkgs.ripgrep
        pkgs.gnumake
        pkgs.wayclip
        pkgs.curl
        pkgs.stow
        self'.packages.bat
        pkgs.killall
        pkgs.bat-extras.batman
        pkgs.udiskie
        pkgs.conceal
        pkgs.rmw
        pkgs.poweralertd
        self'.packages.himalaya
        pkgs.nix-output-monitor
        inputs'.agenix.packages.agenix
        self'.packages.scripts
        pkgs.nixfmt-tree
        pkgs.nixfmt
        pkgs.sequoia-sq
        pkgs.gnupg
        pkgs.proton-vpn-cli
        pkgs.spotatui # Or spotify-player/ncspot/spotifyd
        self'.packages.jrnl
        inputs'.custom-packages.packages.nectarine-gardener
        self'.packages.bash
        self'.packages.zk
        pkgs.talosctl
        pkgs.kubectl
      ];
    };
  flake-file.inputs.custom-packages = {
    url = "sourcehut:~appleptree/nix-packages";
    inputs.nixpkgs.follows = "nixpkgs";
  };
}
