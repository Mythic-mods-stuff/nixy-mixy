{
  flake-file.inputs.brave-origin-flake = {
    url = "github:Daniel-42-z/brave-origin-flake";
    inputs = {
      nixpkgs.follows = "nixpkgs";
      flake-utils.inputs.systems.follows = "systems";
    };
  };
  perSystem =
    { pkgs, self', ... }:
    {
      packages.mullvad-browser = (
        let
          prefs = ''
            pref("browser.urlbar.openintab", true);
            pref("widget.use-xdg-desktop-portal.file-picker", 1);
            pref("security.nocertdb", false);
          '';
          policies.policies = {
            DisableAppUpdate = true;
            PictureInPicture.Enabled = false;
            DNSOverHTTPS.Enabled = false;
            Certificates.Install = [
              self'.packages.homelab-ca-crt
            ];
            SearchEngines.Default = "Startpage";
          };
          policiesJson = pkgs.writeText "policies.json" (builtins.toJSON policies);
        in
        (pkgs.mullvad-browser.override {
          extraPrefs = prefs;
        }).overrideAttrs
          (
            {
              postInstall ? "",
              ...
            }:
            {
              postInstall = postInstall + ''
                install -Dvm644 ${policiesJson} $out/share/mullvad-browser/distribution/policies.json
              '';
            }
          )
      );
    };
  den.aspects.packages._.gui.hjem =
    {
      pkgs,
      self',
      inputs',
      ...
    }:
    {
      packages = [
        self'.packages.mullvad-browser
        pkgs.tor-browser
        pkgs.libreoffice
        pkgs.smile
        pkgs.fractal
        self'.packages.wezterm
        pkgs.proton-vpn
        self'.packages.foot
        pkgs.signal-desktop
        pkgs.warp
        inputs'.brave-origin-flake.packages.default
      ];
    };
}
