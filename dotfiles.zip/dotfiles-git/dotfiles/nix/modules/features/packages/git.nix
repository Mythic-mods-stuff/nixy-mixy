{
  den.aspects.packages._.git.hjem =
    {
      pkgs,
      inputs',
      self',
      ...
    }:
    {
      packages = [
        pkgs.git
        pkgs.git-lfs
        inputs'.nixpkgs-stable.legacyPackages.gitu
        pkgs.delta
        pkgs.radicle-node
        pkgs.difftastic
        self'.packages.jjui
        pkgs.mergiraf
      ];
    };
}
