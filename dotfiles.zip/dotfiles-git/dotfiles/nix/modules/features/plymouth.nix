{
  den.aspects.plymouth.nixos =
    { pkgs, ... }:
    {
      boot = {
        initrd.systemd.enable = true;
        consoleLogLevel = 0;
        initrd.verbose = false;
        kernelParams = [
          "quiet"
          "splash"
          "plymouth.use-simpledrm"
          # "boot.shell_on_fail"
          "loglevel=3"
          "rd.systemd.show_status=false"
          "rd.udev.log_level=3"
          "udev.log_priority=3"
        ];
        plymouth = {
          enable = true;
          theme = "owl";
          themePackages = [
            (pkgs.adi1090x-plymouth-themes.override {
              selected_themes = [ "owl" ];
            })
          ];
        };
      };
    };
}
