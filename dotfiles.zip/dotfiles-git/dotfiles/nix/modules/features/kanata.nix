{
  den.aspects.kanata.nixos =
    { self', ... }:
    {
      services.kanata = {
        enable = true;
        keyboards.main.configFile = self'.packages.kanataConfig;
      };
    };
}
