{
  den.aspects.unfree-predicate.nixos = { lib, config, ... }: {
    options.my.allowedUnfreePackageNames = lib.mkOption {
      type = lib.types.listOf lib.types.str;
      description = "A list of the names of all allowed unfree packages";
      default = [ ];
    };
    config.nixpkgs.config.allowUnfreePredicate =
      pkg: builtins.elem (lib.getName pkg) config.my.allowedUnfreePackageNames;
  };
}
