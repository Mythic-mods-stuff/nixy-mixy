{ den, ... }:
{
  den.aspects.ruhtra = {
    includes = [
      den._.define-user
      den._.primary-user
      den.aspects.packages._.tui
      den.aspects.packages._.cli
      den.aspects.packages._.git
      den.aspects.packages._.gui
      den.aspects.packages._.rice
      den.aspects.packages._.custom
      den.aspects.ssh
      den.aspects.cursor
      den.aspects.wallpapers._.nixos-artwork
      den.aspects.wallpapers._.nature
      den.aspects.passwordass
      den.aspects.pueue
      den.aspects.homelab._.secrets
      den.aspects.impermanence
      den.aspects.secure-boot
      den.aspects.face
      den.aspects.qmk
    ];
    user = {
      hashedPassword = "$y$j9T$RW3zDzjgC1HtyNQ/DIhC3/$JL3/pbD8CdLZ4xv9mUU3SFmV6muhyJOe3NkNnn2wC02";
      extraGroups = [
        "uinput"
        "input"
        "video"
      ];
    };
    hjem = { osConfig, ... }: {
      user = "ruhtra";
      directory = "/home/ruhtra";
      xdg.config.files."jj/repos".source = "/home/ruhtra/dotfiles/.config/jj/repos/";
      xdg.config.files."hut/config".source = osConfig.age.secrets.hut-config.path;
    };
  };
}
