{
  flake.wrappers.kickoff =
    {
      wlib,
      pkgs,
      config,
      lib,
      ...
    }:
    {
      imports = [ wlib.modules.default ];
      options = {
        settings = lib.mkOption {
          type = wlib.types.structuredValueWith {
            nullable = false;
            typeName = "TOML";
          };
          default = { };
          description = ''
            Configuration options for kickoff
          '';
        };
      };
      config = {
        flags."--config" = config.constructFiles.generatedConfig.path;
        constructFiles.generatedConfig = {
          content = builtins.toJSON config.settings;
          relPath = "${config.binName}-config.toml";
          builder = ''${lib.getExe' pkgs.remarshal "json2toml"} "$1" "$2"'';
        };
        package = lib.mkDefault pkgs.kickoff;
      };
    };
}
