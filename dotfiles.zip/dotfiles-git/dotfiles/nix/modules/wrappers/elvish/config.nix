{
  flake.wrappers.elvish.configFile.content = ''
    eval (starship init elvish)
  '';
}
