{
  flake-file.inputs.basix = {
    url = "github:notashelf/basix";
    inputs.nixpkgs.follows = "nixpkgs";
  };
  flake.wrappers.colorscheme =
    { lib, ... }:
    {
      options.colorscheme =
        let
          baseColorOption =
            colorName:
            lib.mkOption {
              type = lib.types.strMatching "#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})";
              description = "Color definition for color ${colorName}";
            };
          colorschemeSubmodule =
            system: colorNames:
            lib.types.submodule {
              options = {
                author = lib.mkOption {
                  type = lib.types.str;
                  description = "The author of the colorscheme";
                };
                name = lib.mkOption {
                  type = lib.types.str;
                  description = "The name of the colorscheme";
                };
                system = lib.mkOption {
                  type = lib.types.enum [ system ];
                  description = "The scheme system used by the colorscheme";
                };
                variant = lib.mkOption {
                  type = lib.types.enum [
                    "dark"
                    "light"
                  ];
                  description = "Whether this is a light or a dark colorscheme";
                };
                palette = lib.mkOption {
                  type = lib.types.submodule {
                    options = lib.pipe colorNames [
                      (map (colorName: {
                        ${colorName} = baseColorOption colorName;
                      }))
                      (lib.foldAttrs (item: acc: acc // item) { })
                    ];
                  };
                  description = "The palette of collors of this colorscheme";
                };
              };
            };
        in
        lib.mkOption {
          description = "A basix colorscheme";
          type =
            lib.types.either
              (colorschemeSubmodule "base16" [
                "base00"
                "base01"
                "base02"
                "base03"
                "base04"
                "base05"
                "base06"
                "base07"
                "base08"
                "base09"
                "base0A"
                "base0B"
                "base0C"
                "base0D"
                "base0E"
                "base0F"
              ])
              (
                colorschemeSubmodule "base24" [
                  "base00"
                  "base01"
                  "base02"
                  "base03"
                  "base04"
                  "base05"
                  "base06"
                  "base07"
                  "base08"
                  "base09"
                  "base0A"
                  "base0B"
                  "base0C"
                  "base0D"
                  "base0E"
                  "base0F"
                  "base10"
                  "base11"
                  "base12"
                  "base13"
                  "base14"
                  "base15"
                  "base16"
                  "base17"
                ]
              );
        };
    };
}
