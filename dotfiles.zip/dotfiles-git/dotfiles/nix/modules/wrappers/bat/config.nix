{
  flake.wrappers.bat.configFile.content = ''
    --theme="Catppuccin Mocha"
  '';
}
