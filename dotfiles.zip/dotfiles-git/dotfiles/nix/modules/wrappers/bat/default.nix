{
  flake.wrappers.bat =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.bat ];
    };
}
