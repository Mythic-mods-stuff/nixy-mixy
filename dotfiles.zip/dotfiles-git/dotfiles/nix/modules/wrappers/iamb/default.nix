{
  flake.wrappers.iamb =
    {
      pkgs,
      wlib,
      lib,
      config,
      ...
    }:
    let
      tomlFmt = pkgs.formats.toml { };
    in
    {
      imports = [ wlib.modules.default ];
      options = {
        settings = lib.mkOption {
          type = tomlFmt.type;
          default = "";
          description = ''
            Iamb configuration options.
          '';
        };
      };
      config = {
        package = lib.mkDefault pkgs.iamb;
        flags."--config-directory" = dirOf (dirOf config.constructFiles.generatedConfig.path);
        constructFiles.generatedConfig = {
          content = builtins.toJSON config.settings;
          relPath = "${config.binName}-config/iamb/config.toml";
          builder = ''mkdir -p "$(dirname "$2")" && ${pkgs.remarshal}/bin/json2toml "$1" "$2"'';
        };
      };
      meta.maintainers = [
        wlib.maintainers.appleptree
      ];
    };
}
