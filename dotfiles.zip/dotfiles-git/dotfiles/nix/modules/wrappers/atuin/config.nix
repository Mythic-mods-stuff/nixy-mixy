{
  flake.wrappers.atuin = {
    settings = {
      invert = true;
      enter_accept = true;
      stats.common_prefix = [
        "sudo"
        "n "
      ];
      keys = { };
      sync.records = true;
      preview = { };
      daemon = { };
    };
  };
}
