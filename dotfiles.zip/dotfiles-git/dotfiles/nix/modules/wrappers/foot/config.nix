{
  flake.wrappers.foot = {
    settings =
      let
        alpha = "0.7";
        font-size = "9";
      in
      {
        main = {
          shell = "nu";
          underline-offset = "7px";
          underline-thickness = "2px";
          font = "MonaspiceXe NF:style:Light:size=${font-size}";
          font-italic = "MonaspiceRn NF:style:Light Italic:size=${font-size}";
          font-bold = "MonaspiceKr NF:style:ExtraBold:size=${font-size}";
          font-bold-italic = "MonaspiceRn NF:style: ExtraBold Italic:size=${font-size}";
        };
        tweak = {
          font-monospace-warn = false;
        };
        mouse = {
          hide-when-typing = "true";
        };
        cursor = {
          beam-thickness = "1";
        };
        colors-dark = {
          inherit alpha;
        };
        colors-light = {
          inherit alpha;
        };
        environment = {
          SHLVL = 0;
        };
      };
  };
}
