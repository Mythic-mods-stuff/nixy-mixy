{
  flake.wrappers.foot = {
    settings = {
      colors-dark = {
        "16" = "fab387";
        "17" = "f5e0dc";
        background = "1e1e2e";
        bright0 = "585b70";
        bright1 = "f38ba8";
        bright2 = "a6e3a1";
        bright3 = "f9e2af";
        bright4 = "89b4fa";
        bright5 = "f5c2e7";
        bright6 = "94e2d5";
        bright7 = "a6adc8";
        cursor = "11111b f5e0dc";
        foreground = "cdd6f4";
        jump-labels = "11111b fab387";
        regular0 = "45475a";
        regular1 = "f38ba8";
        regular2 = "a6e3a1";
        regular3 = "f9e2af";
        regular4 = "89b4fa";
        regular5 = "f5c2e7";
        regular6 = "94e2d5";
        regular7 = "bac2de";
        search-box-match = "cdd6f4 313244";
        search-box-no-match = "11111b f38ba8";
        selection-background = "414356";
        selection-foreground = "cdd6f4";
        urls = "89b4fa";
      };
      colors-light = {
        "16" = "fe640b";
        "17" = "dc8a78";
        background = "eff1f5";
        bright0 = "6c6f85";
        bright1 = "d20f39";
        bright2 = "40a02b";
        bright3 = "df8e1d";
        bright4 = "1e66f5";
        bright5 = "ea76cb";
        bright6 = "179299";
        bright7 = "bcc0cc";
        cursor = "eff1f5 dc8a78";
        foreground = "4c4f69";
        jump-labels = "dce0e8 fe640b";
        regular0 = "5c5f77";
        regular1 = "d20f39";
        regular2 = "40a02b";
        regular3 = "df8e1d";
        regular4 = "1e66f5";
        regular5 = "ea76cb";
        regular6 = "179299";
        regular7 = "acb0be";
        search-box-match = "4c4f69 ccd0da";
        search-box-no-match = "dce0e8 d20f39";
        selection-background = "ccced7";
        selection-foreground = "4c4f69";
        urls = "1e66f5";
      };
    };
  };
}
