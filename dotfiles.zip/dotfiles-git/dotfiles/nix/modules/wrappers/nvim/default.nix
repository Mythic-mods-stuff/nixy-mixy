{ self, ... }:
{
  flake.wrappers.neovim =
    {
      wlib,
      ...
    }:
    {
      imports = [
        wlib.wrapperModules.neovim
        self.wrapperModules.inputs'
      ];
    };
  flake-file.inputs = {
    neovim-nightly-overlay.url = "github:nix-community/neovim-nightly-overlay";
    plugins-listchars = {
      url = "github:0xfraso/nvim-listchars";
      flake = false;
    };
  };
}
