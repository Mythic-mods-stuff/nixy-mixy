-- Set the leader key to space
vim.g.mapleader = " "
vim.g.maplocalleader = " "

-- Enable line numbers
vim.opt.number = true

-- Enable mouse support
vim.opt.mouse = "a"

-- Enable break indent
vim.opt.breakindent = true

-- Save undo history to a file
vim.opt.undofile = true

-- Case-insensitive searching unless \C or one or more capital letters in the search term
vim.opt.ignorecase = true
vim.opt.smartcase = true

-- Always use system clipboard
vim.opt.clipboard = "unnamedplus"
vim.g.clipboard = {
  name = "my-wayclip",
  copy = {
    ["+"] = { "waycopy" },
    ["*"] = { "waycopy" },
  },
  paste = {
    ["+"] = { "waypaste" },
    ["*"] = { "waypaste" },
  },
  cache_enabled = true,
}

-- Keep signcolumn on
vim.opt.signcolumn = "yes"

-- Decrease update time
vim.opt.updatetime = 250

-- Decrease mapped sequence wait time
vim.opt.timeoutlen = 300

-- Configure how new splits should be opened
vim.opt.splitright = true
vim.opt.splitbelow = true

-- Sets display of whitespace characters
vim.opt.list = true

-- Enable live substitutions
vim.opt.inccommand = 'split'

-- Enable editorconfig
vim.g.editorconfig_enable = true

-- Show on which line the cursor is
vim.opt.cursorline = true

-- Minimal number of screen lines to keep above and below the cursor.
vim.opt.scrolloff = 10

-- Highlight when yanking (copying) text
--  Try it with `yap` in normal mode
vim.api.nvim_create_autocmd('TextYankPost', {
  desc = 'Highlight when yanking (copying) text',
  callback = function()
    vim.highlight.on_yank()
  end,
})

-- Enable true color
vim.opt.termguicolors = true

-- Set the shell to nushell
vim.opt.shell = "nu"

-- Enable diagnostics in insert mode
vim.diagnostic.config {
  update_in_insert = true,
  virtual_text = {
    -- prefix = "󰪥",
    prefix = "󰄯",
    -- prefix = "",
    -- prefix = "",
    -- prefix = "",
    -- prefix = "",
    -- prefix = "",
  },
  -- virtual_lines = true,
  severity_sort = true,
  signs = {
    text = {
      [vim.diagnostic.severity.ERROR] = "",
      [vim.diagnostic.severity.WARN]  = "",
      [vim.diagnostic.severity.INFO]  = "",
      [vim.diagnostic.severity.HINT]  = "",
    },
  },
}

-- Enable borders
vim.o.winborder = "rounded"

-- Passwordass yaml filetype
vim.filetype.add({
  pattern = {
    [ [[/dev/shm/pa.*]] ] = 'json',
  },
})
