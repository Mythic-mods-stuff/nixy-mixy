return {
  {
    "nvim-web-devicons",
    dep_of = "hunk.nvim",
  },
  {
    "nui.nvim",
    dep_of = "hunk.nvim",
  },
  {
    "hunk.nvim",
    cmd = { "DiffEditor" },
    after = function()
      require("hunk").setup {
        keys = {
          global = {
            accept = { "c" },
            focus_tree = { "e" },
          },
        },
      }
    end
  },
}
