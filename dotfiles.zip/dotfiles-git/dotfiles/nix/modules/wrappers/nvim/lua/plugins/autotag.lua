return {
  {
    "nvim-ts-autotag",
    lazy = false,
    after = function(plugin)
      require("nvim-ts-autotag").setup {
        opts = {
          enable_close_on_slash = true,
        },
      }
    end,
  },
}
