return {
  {
    "mini.nvim",
    lazy = false, -- For mini.files
    keys = {
      {
        "<leader>f",
        function() MiniFiles.open() end,
        desc = "Open mini.files",
      },
    },
    after = function(plugin)
      require("mini.files").setup {
        mappings = {
          go_in_plus = "<right>",
          go_out_plus = "<left>",
          close = "<esc>",
        },
        options = {
          permanent_delete = false,
          use_as_default_explorer = true,
        },
      }
    end,
  },
}
