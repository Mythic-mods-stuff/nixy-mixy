return {
  {
    "nvim-lilypond-suite",
    lazy = false,
    after = function(plugin)
      require("nvls").setup {
        lilypond = {
          options = {
            pdf_viewer = "zathura",
          },
        },
        latex = {
          options = {
            pdf_viewer = "zathura",
          },
        },
      }
    end,
  },
}
