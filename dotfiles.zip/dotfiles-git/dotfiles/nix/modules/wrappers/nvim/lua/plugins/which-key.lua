return {
  {
    "which-key.nvim",
    lazy = false,
    keys = {
      {
        "<leader>?",
        function() require("which-key").show({ global = false }) end,
        desc = "Buffer Local Keymaps",
      },
    },
    after = function(plugin)
      require("which-key").setup {
        preset = "modern",
        spec = {
          {
            mode = {
              "n",
            },
            {
              "<leader>o",
              icon = {
                icon = "󰼙",
              },
            },
            {
              "<leader>t",
              group = "Trouble",
              icon = {
                icon = "",
                color = "red",
              },
            },
            {
              "<leader>h",
              group = "Hunk",
              icon = {
                icon = "",
                color = "orange",
              },
            },
            {
              "<leader>ht",
              group = "Toggle",
            },
            {
              "<leader>r",
              group = "Rename",
              icon = {
                icon = "",
                color = "yellow",
              },
            },
            {
              "<leader>g",
              group = "Git",
              icon = {
                icon = "󰊢",
                color = "orange",
              },
            },
            {
              "<leader>s",
              group = "Search",
            },
            {
              "<leader>sl",
              group = "LSP",
            },
            {
              "<leader>sv",
              group = "Vim",
            },
            {
              "<leader>sg",
              group = "Git",
              icon = {
                icon = "󰊢",
                color = "orange",
              },
            },
          },
        },
      }
    end,
  },
}
