return {
  {
    "oil.nvim",
    command = "Oil",
    after = function(plugin)
      require("oil").setup {
        default_file_explorer = false,
        columns = {
          "permissions",
          "size",
          "mtime",
          "icon",
        },
        delete_to_trash = true,
        view_options = {
          show_hidden = true,
        },
      }
    end,
  },
}
