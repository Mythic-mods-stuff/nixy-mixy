return {
  {
    "neoscroll.nvim",
    event = "DeferredUIEnter",
    after = function(plugin)
      require("neoscroll").setup {
        duration_multiplier = 0.8,
      }
    end,
  },
}
