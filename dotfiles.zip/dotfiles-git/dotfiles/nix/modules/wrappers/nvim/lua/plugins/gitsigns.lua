return {
  {
    "gitsigns.nvim",
    event = "DeferredUIEnter",
    cmd = "Gitsigns",
    after = function(plugin)
      require("gitsigns").setup {
        on_attach = function(bufnr)
          local gitsigns = require("gitsigns")
          local function map(mode, l, r, opts)
            opts = opts or {}
            opts.buffer = bufnr
            vim.keymap.set(mode, l, r, opts)
          end
          map("n", "]c", function()
            if vim.wo.diff then
              vim.cmd.normal { "]c", bang = true }
            else
              gitsigns.nav_hunk("next")
            end
          end)
          map("n", "[c", function()
            if vim.wo.diff then
              vim.cmd.normal({ "[c", bang = true })
            else
              gitsigns.nav_hunk("prev")
            end
          end)
          map("n", "<leader>hs", gitsigns.stage_hunk, {
            desc = "(Un)Stage hunk",
          })
          map("n", "<leader>hr", gitsigns.reset_hunk, {
            desc = "Reset hunk",
          })
          map("v", "<leader>hs", function()
            gitsigns.stage_hunk({ vim.fn.line("."), vim.fn.line("v") })
          end, {
              desc = "(Un)Stage hunk",
            })
          map("v", "<leader>hr", function()
            gitsigns.reset_hunk({ vim.fn.line("."), vim.fn.line("v") })
          end, {
              desc = "Reset hunk",
            })
          map("n", "<leader>hS", gitsigns.stage_buffer, {
            desc = "Stage file",
          })
          map("n", "<leader>hR", gitsigns.reset_buffer, {
            desc = "Reset file",
          })
          map("n", "<leader>hp", gitsigns.preview_hunk, {
            desc = "Preview hunk",
          })
          map("n", "<leader>hi", gitsigns.preview_hunk_inline, {
            desc = "Preview hunk inline",
          })
          map("n", "<leader>hb", function()
            gitsigns.blame_line({ full = true })
          end, {
              desc = "Blame line",
            })
          map("n", "<leader>hd", gitsigns.diffthis, {
            desc = "Diff file",
          })
          map("n", "<leader>hD", function()
            gitsigns.diffthis("~")
          end, {
              desc = "Diff file --staged",
            })
          map("n", "<leader>hQ", function() gitsigns.setqflist("all") end, {
            desc = "Open global hunklist",
          })
          map("n", "<leader>hq", gitsigns.setqflist, {
            desc = "Open local hunklist",
          })
          map("n", "<leader>htb", gitsigns.toggle_current_line_blame, {
            desc = "Toggle line blame",
          })
          map("n", "<leader>htd", gitsigns.toggle_deleted, {
            desc = "Toggle deleted",
          })
          map("n", "<leader>htw", gitsigns.toggle_word_diff, {
            desc = "Toggle word diff",
          })
          map({ "o", "x" }, "ih", gitsigns.select_hunk, {
            desc = "inner hunk",
          })
        end,
        signs = {
          add = { text = "▌" },
          change = { text = "▌" },
          delete = { text = "" },
          topdelete = { text = "" },
          changedelete = { text = "" },
          untracked = { text = "" },
        },
        signs_staged = {
          add = { text = "▐" },
          change = { text = "▐" },
          delete = { text = "" },
          topdelete = { text = "" },
          changedelete = { text = "" },
          untracked = { text = "" },
        },
        numhl = true,
        attach_to_untracked = true,
      }
    end,
  },
}
