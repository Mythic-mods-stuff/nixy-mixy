return {
  "qmk.nvim",
  lazy = false,
  after = function(plugin)
    require("qmk").setup {
      name = "LAYOUT_split_3x6_3_ex2",
      layout = {
        'x x x x x x x _ x x x x x x x',
        'x x x x x x x _ x x x x x x x',
        'x x x x x x _ _ _ x x x x x x',
        '_ _ _ _ x x x _ x x x _ _ _ _',
      },
    }
  end
}
