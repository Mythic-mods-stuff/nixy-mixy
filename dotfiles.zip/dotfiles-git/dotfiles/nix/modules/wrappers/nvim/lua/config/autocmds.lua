local function format(args)
  require("conform").format {
    bufnr = args.buf,
    lsp_format = "fallback",
  }
end
vim.api.nvim_create_autocmd("BufWritePre", {
  pattern = "*",
  callback = format,
})


vim.api.nvim_create_autocmd('BufEnter', { -- lilypond: Better highlights
  command = "syntax sync fromstart",
  pattern = { '*.ly', '*.ily', '*.tex', '*.texi', '*.texinfo' }
})

vim.api.nvim_create_autocmd('QuickFixCmdPost', { -- lilypond: Show quickfix if errors, else close window
  command = "cwindow",
  pattern = "*"
})
