return {
  {
    "markview.nvim",
    event = "FileType",
    after = function(plugin)
      require("markview").setup {
        typst = {
          enable = false,
        },
      }
    end,
  },
}
