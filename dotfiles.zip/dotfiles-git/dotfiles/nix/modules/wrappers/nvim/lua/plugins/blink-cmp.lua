return {
  {
    "blink-cmp-dictionary",
    dep_of = "blink.cmp",
  },
  {
    "friendly-snippets",
    dep_of = "luasnip",
  },
  {
    "luasnip",
    dep_of = "blink.cmp",
    lazy = false,
    after = function(plugin)
      local ls = require("luasnip")
      require("luasnip.loaders.from_vscode").lazy_load()
      ls.filetype_extend("nunjucks", { "html", "htmldjango" })
    end
  },
  {
    "blink.cmp",
    event = { "DeferredUIEnter" },
    on_require = { "cmp" },
    after = function(plugin)
      require("blink.cmp").setup {
        keymap = { preset = "super-tab" },
        completion = { documentation = { auto_show = true } },
        snippets = {
          preset = "luasnip",
        },
        sources = {
          default = { "dictionary", "lsp", "path", "snippets", "buffer" },
          providers = {
            dictionary = {
              module             = "blink-cmp-dictionary",
              name               = "Dict",
              min_keyword_length = 3,
              max_items          = 8,
              opts               = {
                dictionary_files = function()
                  if vim.bo.filetype == 'lilypond' then
                    return vim.fn.glob(vim.fn.expand('$LILYDICTPATH') .. '/*', true, true)
                  end
                end,
              },
            },
          },
        },
        fuzzy = { implementation = "prefer_rust_with_warning" },
        cmdline = {
          keymap = { preset = "inherit" },
          completion = { menu = { auto_show = true } },
        },
      }
    end,
  },
}
