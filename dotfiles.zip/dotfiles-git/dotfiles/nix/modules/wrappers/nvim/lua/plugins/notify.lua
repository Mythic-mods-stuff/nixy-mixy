return {
  {
    "nvim-notify",
    dep_of = "noice.nvim",
    lazy = false,
    after = function(plugin)
      vim.notify = require("notify")
    end,
  },
}
