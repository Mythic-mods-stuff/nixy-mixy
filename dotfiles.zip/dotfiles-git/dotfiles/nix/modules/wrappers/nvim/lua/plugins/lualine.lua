return {
  {
    "lualine.nvim",
    lazy = false,
    after = function(plugin)
      require("lualine").setup {
        options = {
          theme = "catppuccin-nvim",
          component_separators = {
            left = "",
            right = "",
          },
          section_separators = {
            left = "",
            right = "",
          },
        },
        sections = {
          lualine_a = {
            "mode",
            "selectioncount",
          },
          lualine_b = {
            "encoding",
            "filetype",
            "fileformat",
          },
          lualine_c = {
            {
              "filename",
              symbols = {
                modified = "",
                readonly = "",
                unnamed = "",
                newfile = "",
              },
            },
          },
          lualine_x = {
            {
              require("noice").api.status.mode.get,
              cond = function()
                local result = require("noice").api.status.mode.get()
                if result and result:sub(1, 3) ~= "-- " then
                  return true
                else
                  return false
                end
              end,
            },
            {
              require("noice").api.status.command.get,
              cond = require("noice").api.status.command.has,
            },
          },
          lualine_y = {
            {
              "diagnostics",
              update_in_insert = true,
            },
            {
              "diff",
              symbols = {
                added = " ",
                removed = " ",
                modified = " ",
              },
            },
            "branch",
          },
          lualine_z = {
            "progress",
            "location",
          },
        },
      }
      vim.opt.laststatus = 0
    end,
  },
}
