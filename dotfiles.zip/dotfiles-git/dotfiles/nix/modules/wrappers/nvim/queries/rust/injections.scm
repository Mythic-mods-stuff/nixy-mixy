; extends

(raw_string_literal (string_content)+ @injection.content
 (#match? @injection.content "(SELECT|select|FROM|from|INNER JOIN|inner join|WHERE|where|CREATE|create|DROP|drop|INSERT|insert|UPDATE|update|ALTER|alter)?")
 (#set! injection.language "sql"))
