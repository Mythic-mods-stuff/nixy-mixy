{
  flake.wrappers.wezterm =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.wezterm ];
    };
}
