local wezterm = require("wezterm")
local config = {
  mux_enable_ssh_agent = false,
  harfbuzz_features = {
    "ss01",
    "ss02",
    "ss03",
    "ss04",
    "ss05",
    "ss06",
    "ss07",
    "ss08",
    "ss09",
    "liga",
  },
  font = wezterm.font("Monaspace Xenon", {
    weight = "Regular",
  }),
  font_size = 9,
  font_rules = {
    {
      intensity = "Bold",
      italic = false,
      font = wezterm.font("Monaspace Krypton", {
        weight = "Bold",
      }),
    },
    {
      intensity = "Normal",
      italic = true,
      font = wezterm.font("Monaspace Radon", {
        weight = "Regular",
        style = "Italic",
      }),
    },
    {
      intensity = "Bold",
      italic = true,
      font = wezterm.font("Monaspace Radon", {
        weight = "Bold",
        style = "Italic",
      }),
    },
  },
  color_scheme = "Catppuccin Mocha",
  default_cwd = "/home/ruhtra",
  default_prog = {
    "zellij",
    "-n",
    "welcome",
  },
  enable_scroll_bar = false,
  enable_wayland = true,
  enable_tab_bar = false,
  hide_tab_bar_if_only_one_tab = true,
  window_background_opacity = 0.75,
  window_padding = {
    left = 0,
    right = 0,
    top = 0,
    bottom = 0,
  },
  enable_kitty_keyboard = true,
  window_close_confirmation = "NeverPrompt",
  launch_menu = {},
  disable_default_key_bindings = true,
  debug_key_events = true,
  keys = {
    {
      key = "raw:94",
      mods = "",
      action = wezterm.action.Nop,
    },
    {
      key = "c",
      mods = "CTRL|SHIFT",
      action = wezterm.action.CopyTo "Clipboard",
    },
    {
      key = "v",
      mods = "CTRL|SHIFT",
      action = wezterm.action.PasteFrom "Clipboard",
    },
    {
      key = "Delete",
      mods = "",
      action = wezterm.action.SendKey {
        key = "Delete",
        mods = "",
      },
    },
  },
}

return config
