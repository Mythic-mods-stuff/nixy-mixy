{
  flake.wrappers.swaylock =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.swaylock ];
    };
}
