{
  flake.wrappers.swaylock = {
    addFlag = [
      "--daemonize"
    ];
  };
}
