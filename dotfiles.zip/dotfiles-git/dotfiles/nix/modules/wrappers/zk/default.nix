{ self, ... }:
{
  flake.wrappers.zk =
    {
      wlib,
      lib,
      config,
      pkgs,
      ...
    }:
    {
      imports = [
        wlib.modules.default
        self.wrapperModules.inputs'
      ];
      options = {
        settings = lib.mkOption {
          type = wlib.types.structuredValueWith { typeName = "YAML 1.1"; };
          default = { };
          description = ''
            Configuration of zk.
            See <https://zk-org.github.io/zk/config/config.html>
          '';
        };
      };

      config = {
        package = lib.mkDefault pkgs.zk;
        # flags."--config" = config.constructFiles.generatedConfig.path;
        env.ZK_CONFIG_DIR = dirOf config.constructFiles.generatedConfig.path;
        constructFiles.generatedConfig = {
          content = builtins.toJSON config.settings;
          relPath = "${config.binName}-config/config.toml";
          builder = ''${lib.getExe' pkgs.remarshal "json2toml"} "$1" "$2"'';
        };
        meta = {
          maintainers = [ wlib.maintainers.appleptree ];
          platforms = lib.platforms.linux;
        };
      };
    };
}
