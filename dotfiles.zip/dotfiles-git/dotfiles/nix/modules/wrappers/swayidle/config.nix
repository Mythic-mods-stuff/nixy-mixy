{
  flake.wrappers.swayidle =
    {
      lib,
      pkgs,
      self',
      ...
    }:
    {
      events = {
        lock = lib.getExe self'.packages.swaylock;
        before-sleep = "loginctl lock-session";
        after-resume = "${lib.getExe pkgs.niri} msg action power-on-monitors";
      };
      timeouts = [
        {
          timeout = 59;
          command = "${lib.getExe pkgs.brillo} -O";
        }
        {
          timeout = 1 * 60;
          command = "${lib.getExe pkgs.brillo} -S 0.25% -u 400000";
          resumeCommand = "${lib.getExe pkgs.brillo} -I -u 400000";
        }
        {
          timeout = 2 * 60;
          command = "${lib.getExe pkgs.niri} msg action power-off-monitors";
        }
        {
          timeout = 5 * 60;
          command = "loginctl lock-session";
        }
        {
          timeout = 10 * 60;
          command = "systemctl suspend-then-hibernate";
        }
      ];
    };
}
