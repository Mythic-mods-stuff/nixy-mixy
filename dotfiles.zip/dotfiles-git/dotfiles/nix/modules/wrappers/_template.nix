{ self, ... }:
{
  flake.wrappers._name_ =
    {
      wlib,
      lib,
      config,
      pkgs,
      ...
    }:
    {
      imports = [
        wlib.modules.default
        self.wrapperModules.inputs'
      ];
      options = {
        settings = lib.mkOption {
          type = wlib.types.structuredValueWith { typeName = "YAML 1.1"; };
          default = { };
          description = ''
            Configuration of _name_.
            See `_name_ --help-config`
          '';
        };
      };

      config.package = lib.mkDefault pkgs._name_;

      config = {
        flags."--config" = config.constructFiles.generatedConfig.path;
        constructFiles.generatedConfig = {
          content = lib.generators.toYAML { } config.settings;
          relPath = "${config.binName}.yaml";
        };
        meta = {
          maintainers = [ wlib.maintainers.appleptree ];
          platforms = lib.platforms.linux;
        };
      };
    };
}
