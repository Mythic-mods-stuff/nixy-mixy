{
  flake.wrappers.alacritty = {
    settings = {
      font = {
        bold = {
          family = "MonaspiceKr Nerd Font";
          style = "Bold";
        };
        bold_italic = {
          family = "MonaspiceRn Nerd Font";
          style = "Bold Italic";
        };
        italic = {
          family = "MonaspiceRn Nerd Font";
          style = "Italic";
        };
        normal = {
          family = "MonaspiceXe Nerd Font";
          style = "Regular";
        };
        size = 10;
      };
      mouse.hide_when_typing = true;
      terminal = {
        shell = {
          args = [
            "-l"
            "welcome"
          ];
          program = "zellij";
        };
      };
      window = {
        blur = true;
        dynamic_padding = false;
        dynamic_title = true;
        opacity = 0.75;
      };
    };
  };
}
