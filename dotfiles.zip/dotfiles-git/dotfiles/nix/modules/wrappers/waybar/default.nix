{
  flake.wrappers.waybar =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.waybar ];
    };
}
