{
  flake.wrappers.waybar = {
    settings = {
      "hyprland/workspaces" = {
        all-outputs = true;
        format = "{icon} {id}";
        format-icons = {
          active = " ";
          default = " ";
          empty = " ";
          persistent = " ";
          special = " ";
          urgent = " ";
        };
        show-special = true;
        move-to-monitor = true;
      };
      network = {
        interface = "wlan0";
        family = "ipv6";
        format-wifi = "{essid}";
        format-disconnected = "No Wi-Fi";
      };
      user = {
        format = " {work_H}:{work_M}";
        open-on-click = false;
      };
      pulseaudio = {
        format-icons.default = [
          " "
          " "
        ];
        format = "{icon}{volume}%";
        format-bluetooth = "{icon}{volume}%";
        format-muted = " ";
        on-click = "wpctl set-mute @DEFAULT_AUDIO_SINK@ toggle";
      };
      idle_inhibitor = {
        format = "{icon} ";
        format-icons = {
          activated = "";
          deactivated = "";
        };
      };
      memory.format = " {percentage}%";
      disk = {
        unit = "GiB";
        format = " {used}/{total}";
      };
      battery = {
        format = "{icon} {capacity}%";
        format-time = "{H}:{m} left ";
        format-icons = [
          ""
          ""
          ""
          ""
          ""
        ];
      };
      backlight = {
        format = "{icon} {percent}%";
        format-icons = [
          "󰃞"
          "󰃠"
        ];
        on-scroll-up = "brightnessctl s 1%+";
        on-scroll-down = "brightnessctl s 1%-";
      };
      clock = {
        format = " {:%H:%M}";
        timezone = "Europe/Berlin";
      };
      "custom/screen-time" = {
        exec = "screen-time week-time";
        interval = 1;
        format = " {}";
      };
    };
  };
}
