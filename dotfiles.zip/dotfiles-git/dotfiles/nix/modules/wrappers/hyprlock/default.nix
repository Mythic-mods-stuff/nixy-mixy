{ self, inputs, ... }:
{
  flake.wrappers.hyprlock =
    { wlib, ... }:
    {
      imports = [
        wlib.wrapperModules.hyprlock
        self.wrapperModules.colorscheme
      ];
      colorscheme = inputs.basix.schemeData.base16.catppuccin-mocha;
    };
}
