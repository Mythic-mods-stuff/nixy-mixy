{
  flake.wrappers.starship-transient = {
    binName = "starship-transient";
    settings = {
      format = "$directory$time$status$sudo$shell";
      add_newline = false;
      directory = {
        format = "[$read_only]($read_only_style)[$path ]($style)";
        home_symbol = " ";
        read_only = " ";
        read_only_style = "bold fg:red";
        style = "bold fg:maroon";
        substitutions = {
          Desktop = " ";
          Documents = "󰈙 ";
          Downloads = " ";
          Music = "󰝚 ";
          Pictures = " ";
          Programming = "󰲋 ";
          Videos = " ";
        };
        truncate_to_repo = false;
        truncation_length = -1;
        truncation_symbol = " /";
        use_os_path_sep = false;
      };
      time = {
        disabled = false;
        format = "[ $time]($style) ";
        style = "bold fg:mauve";
        use_12hr = false;
      };
      status = {
        disabled = false;
        format = "[$symbol$status]($style) ";
        not_executable_symbol = " ";
        not_found_symbol = " ";
        sigint_symbol = " ";
        signal_symbol = " ";
        style = "bold fg:red";
        symbol = " ";
      };
      sudo = {
        disabled = false;
        format = "[$symbol]($style)";
        style = "bold fg:red";
        symbol = " ";
      };
      shell = {
        bash_indicator = "[ba](bold fg:text)";
        cmd_indicator = "[cmd](fg:subtext1)";
        disabled = false;
        elvish_indicator = "[elvi](bold fg:green)";
        fish_indicator = "[fi](bold fg:blue)";
        format = "$indicator[sh]($style) ";
        ion_indicator = "[ion](bold fg:sapphire)";
        nu_indicator = "[nu](bold fg:teal)";
        powershell_indicator = "[power](bold fg:lavender)";
        style = "fg:text";
        tcsh_indicator = "[tc](bold fg:red)";
        unknown_indicator = "[ ](bold fg:red)";
        xonsh_indicator = "[xon](bold fg:sky)";
        zsh_indicator = "[z](bold fg:peach)";
      };
    };
  };
}
