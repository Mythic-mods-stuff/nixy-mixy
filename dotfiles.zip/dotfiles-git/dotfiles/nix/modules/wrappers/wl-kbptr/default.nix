{
  flake.wrappers.wl-kbptr =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.wl-kbptr ];
    };
}
