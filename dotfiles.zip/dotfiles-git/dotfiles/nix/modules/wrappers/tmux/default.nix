{ self, ... }:
{
  flake.wrappers.tmux =
    { wlib, ... }:
    {
      imports = [
        wlib.wrapperModules.tmux
        self.wrapperModules.inputs'
      ];
    };
}
