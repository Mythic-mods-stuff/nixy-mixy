{
  flake.wrappers.fuzzel =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.fuzzel ];
    };
}
