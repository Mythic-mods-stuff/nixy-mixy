{
  flake.wrappers.ion =
    {
      lib,
      wlib,
      config,
      pkgs,
      ...
    }:
    {
      imports = [ wlib.modules.default ];
      options = {
        configFile = lib.mkOption {
          type = wlib.types.file {
            path = lib.mkOptionDefault config.constructFiles.generatedConfig.path;
          };
          default.content = "";
          description = ''
            Initial commands file for ion.
          '';
        };
      };
      config = {
        constructFiles.generatedConfig = {
          content = config.configFile.content;
          relPath = "${config.binName}-config/ion/initrc";
        };
        env.XDG_CONFIG_HOME = dirOf (dirOf config.constructFiles.generatedConfig.path);
        package = lib.mkDefault pkgs.ion;
      };
    };
}
