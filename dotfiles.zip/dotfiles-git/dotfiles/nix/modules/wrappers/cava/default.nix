{
  flake.wrappers.cava = (
    {
      config,
      lib,
      wlib,
      pkgs,
      ...
    }:
    let
      iniFmt = pkgs.formats.ini { };
    in
    {
      imports = [ wlib.modules.default ];
      options = {
        settings = lib.mkOption {
          type = iniFmt.type;
          default = { };
          description = ''
            Configuration options for cava.
          '';
        };
      };
      config = {
        flags = {
          "-p" = "${iniFmt.generate "cava-config" config.settings}";
        };
        package = lib.mkDefault pkgs.cava;
      };
    }
  );
}
