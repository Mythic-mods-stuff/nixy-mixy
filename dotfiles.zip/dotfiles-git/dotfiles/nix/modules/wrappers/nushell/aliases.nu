alias lss =	eza -lahgo@ --git --icons=always --color=always --time-style long-iso
alias lt = lss --tree
alias lst = lss --tree --git-ignore
alias stow-config = stow -d ~/dotfiles . -vv --no-folding # If updating here also update in preservation config and nectarine-gardener
alias fz = sk --format {get name} --preview {}
alias launch-niri = kmscon-launch-gui niri-session
alias launch-gnome = kmscon-launch-gui dbus-run-session -- gnome-shell --display-server
alias launch-cosmic = kmscon-launch-gui start-cosmic
alias kill-gnome = killall .gnome-shell-wr
alias json2nix = nix eval --expr $"builtins.fromJSON ''($in)''"
