def passwords [] {pa list | split row "\n"}

def "pa doppler fetch" [] {
  $env.DOPPLER_TOKEN = pa s doppler | get api-token
  # $env.PA_NOGIT = ""
  let projects = doppler projects --json | from json | get name
  let configs = $projects
    | each { |project|
      let project_configs = doppler configs --project $project --json | from json | get name
      let configs =  $project_configs
        | each { |config|
          let content = doppler secrets --project $project --config $config --json
            | from json
            | items { |key, value|
              [$key, $value.computed]
            }
            | into record
          [$config, $content]
        }
        | into record
      [$project, $configs]
    }
    | into record
  $configs
    | items { |project, configs|
      $configs
        | items { |config, secrets|
          let environment = $secrets.DOPPLER_ENVIRONMENT
          let location_config = if ($config | str contains "_") {
            $config | split row "_" | skip 1 | str join
          } else {
            $config
          }
          let location = $"doppler/($project)/($environment)/($location_config)"
          $env.TEXT = $secrets | to json
          $env.EDITOR = "script-write-text-file"
          print $"Editing ($location)..."
          pa edit $location
        }
    }
  job spawn {
    pa git add ~/.local/share/pa/passwords
    pa git commit -m "fetch 'doppler/*' from doppler-cli"
    pa git push --set-upstream origin main
  }
}

# Generate a new password and auto-git-push afterwards
def "pa a" [
  pass: string # The name of the password to generate
] {
  if $pass in (passwords) {eror make "Password already exists"}
  "y" | pa add $pass
  $env.TEXT = {password: (pa show $pass)} | to json
  $env.EDITOR = "script-write-text-file"
  pa edit $pass
  job spawn {
    pa git push --set-upstream origin main
  }
}

# Show the parsed json content of the password
def "pa s" [
  pass: string@passwords # The password to show as parsed json
]: nothing -> record {
  pa show $pass | from json
}

# Delete a password and auto-git-push afterwards
def "pa d" [
  pass: string@passwords # The password to delete
] {
  "y" | pa delete $pass
  job spawn {
    pa git push --set-upstream origin main
  }
}

# Edit a password using nushell
#
# The handed over closure is getting piped in the current parsed json value of the password
# The output of the closure is serialized as json and written to the secret
#
# Automatically git-push afterwards
def "pa e" [
  pass: string@passwords # The password to edit
  processor: closure # A closure for editing the password
] {
  let current_content = if $pass in (passwords) {
    pa s $pass
  } else {
    null
  }
  let result_content = $current_content | do $processor
  $env.TEXT = $result_content | to json
  $env.EDITOR = "script-write-text-file"
  pa edit $pass
  job spawn {
    pa git push --set-upstream origin main
  }
  if ($pass | str starts-with "doppler/") {
    let segments = $pass | split row "/" | skip 1
    let project = $segments.0
    let config = if $segments.1 != $segments.2 {
      $"($segments.1)_($segments.2)"
    } else {
      $segments.2
    }
    job spawn {
      pa s $pass | to json | save -f /dev/shm/pass.json
      doppler secrets upload --project $project --config $config /dev/shm/pass.json
      rm /dev/shm/pass.json
    }
  }
}

# Auto-fill a password, using the instructions in the autofill field
def "pa f" [
  pass: string@passwords # The password to auto-fill
] {
  let secret = pa s $pass
  let auto_cmds = ($secret
    | get autofill
    | each {|it|
      if ($it | str starts-with "$") {
        ["wtype" ($secret | get ($it | str substring 1..))]
      } else if ($it | str starts-with "|") {
        ["sleep" ($it | str substring 1.. | into duration)]
      } else {
        ["wtype" "-k" $it]
      }
    }
  )
  $auto_cmds | each {|it|
    match $it {
      ["wtype", ..$wtype_args] => { wtype ...$wtype_args },
      ["sleep", $first_arg, ..$sleep_args] => { sleep $first_arg ...$sleep_args },
    }
  }
}

