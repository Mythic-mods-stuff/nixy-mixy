source ~/.cache/starship/init.nu
source ~/.cache/zoxide/init.nu
source ~/.cache/carapace/init.nu
source ~/.cache/television/init.nu
source ~/.cache/atuin/init.nu
source ~/.cache/nix-your-shell/init.nu
