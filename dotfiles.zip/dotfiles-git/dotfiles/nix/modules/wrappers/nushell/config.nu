# print "Starting new shell"
source ./envvars.nu
source ./aliases.nu
source ./passwordass.nu
source ./cmds.nu
source ./hooks.nu
use ./catppuccin-mocha.nu
$env.config = {
	cursor_shape: {
		vi_insert: line
		vi_normal: block
		emacs: underscore
	}
	edit_mode: "vi"
	table: {
		mode: compact_double,  # rounded, compact, compact_double, light, reinforced, heavy
	}
	show_banner: false
	color_config: (catppuccin-mocha)
	use_kitty_protocol: true
}
source ./source-configs.nu
job spawn {ssh-add}
print ""
