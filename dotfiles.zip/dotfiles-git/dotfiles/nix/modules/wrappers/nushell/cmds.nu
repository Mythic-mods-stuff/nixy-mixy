def --env --wrapped z [...rest: string@"nu-complete zoxide path"] {
  __zoxide_z ...$rest
}
def "nu-complete zoxide path" [context: string] {
  let parts = $context | str trim --left | split row " " | skip 1 | each { str lowercase }
  let completions = (
    ^zoxide query --list --exclude $env.PWD -- ...$parts
    | lines
    | each { |dir|
      if ($parts | length) <= 1 {
        $dir
      } else {
        let dir_lower = $dir | str lowercase
        let rem_start = $parts | drop 1 | reduce --fold 0 { |part, rem_start|
          ($dir_lower | str index-of --range $rem_start.. $part) + ($part | str length)
        }
        {
          value: ($dir | str substring $rem_start..),
          description: $dir
        }
      }
    })
  {
    options: {
      sort: false,
      completion_algorithm: substring,
      case_sensitive: false,
    },
    completions: $completions,
  }
}
# Get an overview of flake.lock
def flake.lock [
  --url # Include git URLs and paths of file inputs
  --inputs # Include nested inputs
] {
  open flake.lock
  | from json
  | get nodes
  | transpose
  | rename name value
  | each {|it|
    let result = {
      name: $in.name,
      lastModified: ($in.value.locked?.lastModified? | if $in == null {null} else {into datetime -f '%s'}),
      type: $in.value.locked?.type,
      owner: $in.value.locked?.owner?,
      repo: $in.value.locked?.repo?,
      rev: $in.value.locked?.rev?,
    }
    if $url {
      $result | insert url $it.value.locked?.url? | default $it.value.locked?.path?
    } else if $inputs {
      $result | insert inputs $it.value.inputs?
    } else {
      $result
    }
  }
}
# Get radicle repos on seed.radicle.at
def "rad get-repos" [] {
  http get https://seed.radicle.at/api/v1/delegates/(rad self --did)/projects?show=all
  | reject defaultBranch threshold visibility delegates patches issues
}
# Exit niri and shutdown
def sd [] {
  sudo echo
  niri msg action quit --skip-confirmation
  sudo shutdown now
}
# Wrap jrnl with an auto-committer and pusher
@complete external
def --wrapped jrnl [...args] {
  ^jrnl ...$args
  job spawn {
    jj --repository ~/.local/share/jrnl commit --message "feat: Auto update journal"
    jj --repository ~/.local/share/jrnl abandon '(~empty())..'
    jj --repository ~/.local/share/jrnl tug
    jj --repository ~/.local/share/jrnl git push
  }
}
# Wrap radicle with the radicle passphrase
@complete external
def --wrapped rad [...args] {
  with-env {RAD_PASSPHRASE: (pa s ssh/radicle/nectarine-tree | get password)} {
    ^rad ...$args
  }
}
# Put anything into a nushell table
@complete external
def --wrapped jc [...args] {
  let result = $in | jc ...$args
  $result | from json
}

# Print the tailscale device ID of the device with the name
def ts-id [
  name: string # The name of the device
] {
  (
    tscli -k (pa s tailscale-apikey | get password) list devices
      | from json
      | where name == $name
      | get 0
      | get nodeId
  )
}

# Replace ssh-add with one using the custom askpass script
@complete external
def --wrapped ssh-add [...args] {
  with-env {
    SSH_ASKPASS: "script-askpass"
    SSH_ASKPASS_REQUIRE: "force"
    SSH_ASKPASS_PASS_TO_GET: "ssh/nectarine-tree"
  } {
    ^ssh-add ...$args
  }
}

# Temporarily copy a string to clipboard, clearing after 45 seconds
def tmp-copy [
  arg: string # The string to copy
  name: string = "something" # The name to display in notification
  delay: string = "45s" # Duration to wait before clearing clipboard
] {
  $arg | waycopy
  fyi $"Copied ($name) to clipboard"
  pueue add -d $delay -- "'' | waycopy; fyi 'Cleared clipboard'"
}

# Execute an alias with sudo
def --wrapped asudo [
  alias: string # The alias to execute
  ...args
] {
  let cmd = awhich $alias | get expansion | split row " "
  let cmd_list = ["sudo" ...$cmd ...$args]
  run-external ...$cmd_list
}

# Find out what an alias refers to
def awhich [alias: string] {
  scope aliases | where name == $alias
}

# Load a .env file
def load-dotenv [] {
  open .env
  | split row "\n"
  | each {|it|
    let pos = $it | str index-of "="
    [($it | str substring ..($pos - 1)) ($it | str substring ($pos + 1)..)]}
  | into record
  | load-env
}

# Quit the current zellij session without making it resurrectable
def ze [] {
	zellij delete-session --force $env.ZELLIJ_SESSION_NAME
}

# Browse a remote repo via soft-serve (cb for code-browser)
def cb [
	repo: string
] {
	let dir_path = $env.CODE_BROWSER_PATH? | default "/tmp/code-browser-git-repos"
	mkdir $dir_path
	let parsed = $repo | parse --regex '^(?P<proto>https://)?(?P<domain>\w+\.\w+/)?(?P<rest>.*)'
	mut final = $parsed.0
  $final.proto = if $final.proto == null {"https://"} else {$final.proto}
  $final.domain = if $final.domain == null {"github.com/"} else {$final.domain}
	let final_str = [$final.proto $final.domain $final.rest] | str join
	let path = [$dir_path ($final.rest | str replace -a "/" "_")] | path join
	do --ignore-errors {
		git clone $final_str $path #e>| ignore
	}
	nix run nixpkgs#soft-serve -- browse $path
  rm -rf $dir_path
}

# Run the command with the arguments with nix
def --wrapped r [
	command: string # The command to run
	...args # The args to hand over to the command
] {
  let final_command = if ($command | str starts-with "n#") {
    "nixpkgs#" + ($command | str substring 2..)
  } else {
    $command
  }
  let cmd_list = ["nix" "run" "--option" "access-tokens" $"github.com=(pa s github.com | get pat)" $final_command "--" ...$args]
  let pipe_input = $in
  if ($pipe_input | describe) == "nothing" {
    run-external ...$cmd_list
  } else {
    $pipe_input | run-external ...$cmd_list
  }
}

# Run the command from nixpkgs with the arguments with nix
def --wrapped nr [
  command: string # The command to run
  ...args # The args to hand over to the command
] {
  r $"nixpkgs#($command)" ...$args
}

# Run a nix shell
def --wrapped s [
  --package-prefix: string # The string to prefix all the packages with
  ...args: string # The packages with command to put into the shell
] {
  let separated_args = $args | split list "--"
  let packages = $separated_args.0 | each {|it| [$package_prefix $it] | str join}
  let shell_cmd = $separated_args | skip 1 | flatten
  let cmd_list = if ($shell_cmd | is-empty) {
    [...$packages "--command" "nu"]
  } else {
    [...$packages "--command" ...$shell_cmd]
  }
  let pipe_input = $in
  if ($pipe_input | describe) == "nothing" {
    nix shell ...$cmd_list
  } else {
    $pipe_input | nix shell ...$cmd_list
  }
}

# Run in a nix shell with nixpkgs
def --wrapped ns [
  ...args: string # The packages with command to put into the shell
] {
  s --package-prefix nixpkgs# ...$args
}

def "list index-of" [item: any] {
  enumerate | where item == $item | first | get index
}

def xor [a: bool, b: bool] {
  # return ((a or b) and (not (a and b)))
  return ($a | into int | bits xor ($b | into int)) | into bool
}

# Move a config directory from ~/.config to ~/dotfiles/.config
# When it doesn't exist yet, create an empty directory
def add-config [
	name: string  # The name of the directory in ~/.config
] {
	let config_path = ("/home/ruhtra/.config" | path join $name)
	let dotfiles_path = ("/home/ruhtra/dotfiles/.config" | path join $name)
	if ($config_path | path exists) {
		mv $config_path $dotfiles_path
	} else {
		mkdir $dotfiles_path
	}
}
