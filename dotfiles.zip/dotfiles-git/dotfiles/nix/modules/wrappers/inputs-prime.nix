{ inputs, config, ... }:
{
  flake.wrappers.inputs' =
    { pkgs, ... }:
    {
      _module.args = {
        self' = config.perInput pkgs.stdenv.hostPlatform.system inputs.self;
        inputs' = builtins.mapAttrs (
          inputName: input: config.perInput pkgs.stdenv.hostPlatform.system input
        ) inputs;
      };
    };
}
