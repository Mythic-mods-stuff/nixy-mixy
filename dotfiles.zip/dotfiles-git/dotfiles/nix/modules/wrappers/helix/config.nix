{
  flake.wrappers.helix = {
    settings = {
      theme = "catppuccin_mocha";
      editor = {
        true-color = true;
        line-number = "absolute";
        cursorline = true;
        color-modes = true;
        bufferline = "always";
        default-line-ending = "lf";
        popup-border = "all";
        statusline = {
          left = [
            "mode"
            "spinner"
            "version-control"
            "register"
          ];
          center = [
            "read-only-indicator"
            "file-modification-indicator"
            "file-name"
            "separator"
            "file-type"
            "separator"
            "file-encoding"
            "file-line-ending"
            "separator"
            "total-line-numbers"
          ];
          right = [
            "diagnostics"
            "workspace-diagnostics"
            "position-percentage"
            "selections"
            "primary-selection-length"
          ];
          separator = "❭";
          mode = {
            normal = "--- NORMAL ---";
            insert = "~~~ INSERT ~~~";
            select = "——— SELECT ———";
          };
        };
        lsp.display-inlay-hints = true;
        cursor-shape = {
          insert = "bar";
          normal = "block";
          select = "underline";
        };
        whitespace = {
          render = {
            tab = "all";
            nbsp = "all";
            nnbsp = "all";
            newline = "all";
            space = "none";
          };
          characters = {
            newline = "¶";
            tab = "»";
          };
        };
        indent-guides.render = true;
        soft-wrap.enable = true;
      };
      keys.normal = {
        C-left = "jump_view_left";
        C-right = "jump_view_right";
        C-up = "jump_view_up";
        C-down = "jump_view_down";
        tab = ":bn";
        C-r = [
          ":reload"
          ":w"
        ];
      };
    };
  };
}
