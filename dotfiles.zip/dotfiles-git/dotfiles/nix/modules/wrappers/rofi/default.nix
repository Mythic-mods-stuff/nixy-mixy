{
  flake.wrappers.rofi =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.rofi ];
    };
}
