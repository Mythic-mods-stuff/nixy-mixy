{
  flake.wrappers.fish.configFile.content = ''
    starship init fish | source
  '';
}
