{
  flake.wrappers.himalaya =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.himalaya ];
    };
}
