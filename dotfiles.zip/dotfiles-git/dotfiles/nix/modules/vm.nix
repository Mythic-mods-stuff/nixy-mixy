# enables `nix run .#vm`. it is very useful to have a VM
# you can edit your config and launch the VM to test stuff
# instead of having to reboot each time.
{ self, ... }:
{
  perSystem =
    { pkgs, ... }:
    {
      packages.seed-vm = pkgs.writeShellApplication {
        name = "vm";
        text =
          let
            host = self.nixosConfigurations.nectarine-seed.config;
          in
          ''
            ${host.system.build.vm}/bin/run-${host.networking.hostName}-vm "$@"
          '';
      };
      packages.vm = pkgs.writeShellApplication {
        name = "vm";
        text =
          let
            host = self.nixosConfigurations.nectarine-tree.config;
          in
          ''
            ${host.system.build.vm}/bin/run-${host.networking.hostName}-vm "$@"
          '';
      };
    };
}
