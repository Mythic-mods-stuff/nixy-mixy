{
  perSystem =
    { pkgs, ... }:
    {
      packages.gammad =
        let
          version = "1.0.0";
          name = "gammad";
        in
        pkgs.stdenv.mkDerivation {
          inherit name version;
          src = pkgs.fetchFromGitHub {
            owner = "nedimzecic";
            repo = "gammad";
            rev = "v${version}";
            hash = "sha256-B6SK89gjhaLmG5YovLD0Bp/BIdgP4w8aK13MOw3vFgA=";
          };
          buildInputs = [
            pkgs.libdrm
          ];
          nativeBuildInputs = [
            pkgs.pkg-config
          ];
          # postInstall = ''
          #   sed -i -e 's|<drm.h>|<libdrm/drm.h>|' $dev/include/xf86drm.h
          # '';
        };
    };
}
