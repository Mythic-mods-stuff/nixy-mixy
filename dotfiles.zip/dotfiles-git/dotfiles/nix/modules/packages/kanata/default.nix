{
  perSystem =
    { pkgs, ... }:
    {
      packages.kanataConfig = pkgs.writeText "kanata.kbd" (builtins.readFile ./kanata.kbd);
    };
}
