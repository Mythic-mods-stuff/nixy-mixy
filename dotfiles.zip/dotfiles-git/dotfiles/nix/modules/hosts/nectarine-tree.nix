{
  den,
  inputs,
  self,
  ...
}:
{
  den.hosts.x86_64-linux.nectarine-tree.users.ruhtra = { };
  # host aspect
  den.aspects.nectarine-tree = {
    includes = [
      den._.hostname
      den.aspects.locale
      den.aspects.neo-keyboard
      den.aspects.homelab._.dns
      den.aspects.homelab._.wireguard
      den.aspects.homelab._.secrets
      den.aspects.homelab._.webdav
      den.aspects.homelab._.tls
      den.aspects.iwd
      den.aspects.cachix._.nix-community
      den.aspects.disko
      den.aspects.ssh
      den.aspects.nix-config
      den.aspects.crypttab
      den.aspects.plymouth
      den.aspects.bluetooth
      den.aspects.direnv
      den.aspects.fonts
      den.aspects.ddc
      den.aspects.niri
      den.aspects.virtualization
      den.aspects.power-saving
      den.aspects.printing
      den.aspects.sudo-rs
      den.aspects.gnome
      den.aspects.kmscon
      den.aspects.kanata
      den.aspects.nh
      den.aspects.pipewire
      den.aspects.xdg-default-apps
      den.aspects.nix-monitored
      den.aspects.cosmic
      den.aspects.secure-boot
      den.aspects.flatpak
      den.aspects.face
      den.aspects.auto-kb
      den.aspects.unfree-predicate
      den.aspects.spicetify
    ];
    nixos = { pkgs, ... }: {
      imports = [
        inputs.agenix.nixosModules.default
      ];
      hardware.facter.reportPath = ./nectarine-tree.json;
      programs.nix-ld.enable = true;
      age.identityPaths = [ "/persist/home/ruhtra/.local/share/pa/identities" ];
      users.mutableUsers = false;
      services.davfs2.enable = true;
      programs.bash.loginShellInit = ''
        if ! [ "$TERM" = "dumb" ] && [ -z "$BASH_EXECUTION_STRING" ]; then
          exec dbus-run-session -- nu
        fi
      '';
      environment.etc."xdg/monitors.xml".source = ./monitors.xml;
      services.udev.extraRules = ''
        ACTION=="add", SUBSYSTEM=="input", ATTRS{name}=="Keebart Corne Choc Pro", TAG+="systemd", ENV{SYSTEMD_USER_SERVICE}="script-auto-kb-us.service"
      '';
      age.secrets.hut-config = {
        file = "${self.outPath}/secrets/hut-config.age";
        owner = "ruhtra";
      };
      services.usbmuxd.enable = true;
      environment.systemPackages = [
        pkgs.libimobiledevice
        pkgs.ifuse
      ];
    };
  };
}
