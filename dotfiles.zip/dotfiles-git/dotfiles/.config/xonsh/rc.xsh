from pathlib import Path
import os.path
import sys

def last_log(args: list[str]):
	directory = Path(args[0])
	return list(list(directory.iterdir())[-1].iterdir())[-1]

def recreate_env(args: list[str]):
	"""Recreate a virtualenv with vox."""
	name = args[0]
	get_requirements(name)
	$(vox rm @(name) -f)
	$(vox new @(name) -a)
	$(pip install -r ~/.virtualenvs/@(name)_req.txt)
	$(vox deactivate)

def get_requirements(args: list[str]):
	name = args[0]
	$(vox activate @(name))
	$(pip freeze > ~/.virtualenvs/@(name)_req.txt)
	$(vox deactivate)

def get_all_requirements(args: list[str]):
	directory = (Path("~") / ".virtualenvs").expanduser()
	[
		get_requirements([dirname.stem])
		for dirname in directory.iterdir()
		if dirname.is_dir()
	]

def recreate_envs(args: list[str]):
	directory = (Path("~") / ".virtualenvs").expanduser()
	[recreate_env([dirname.stem]) for dirname in directory.iterdir() if dirname.is_dir()]

def recreate_aliases():
	new_aliases = {}
	if 'clear' in aliases:
		del aliases['clear']
	for key, value in aliases.items():
		if isinstance(value, list) and value[0] == 'C:\\WINDOWS\\system32\\cmd.exe':
			new_aliases['win-cmd-' + key] = value
		else:
			new_aliases[key] = value
	aliases.clear()
	for key, value in new_aliases.items():
		aliases[key] = value


def create_aliases():
	aliases["imgcat"] = "wezterm imgcat"
	aliases["git-log"] = "git log --graph --oneline -20"
	aliases["cat"] = "rich -n --pager --theme catppuccin-mocha"
	aliases["win-love"] = "~/c/scoop/shims/love.exe"
	aliases["cd"] = "z"
	aliases["md"] = "mkdir"
	aliases["vi"] = $(which vim)
	aliases["vim"] = "nvim"
	ls = "eza -laXhgo@ --git --icons --no-quotes --time-style long-iso"  # --git-repos --total-size
	aliases["ls"] = ls
	aliases["long-ls"] = ls + " --git-repos" + "--total-size"
	aliases["hardfought"] = "ssh nethack@hardfought.org"
	aliases["last-log"] = last_log
	aliases["recreate-env"] = recreate_env
	aliases["recreate-envs"] = recreate_envs
	aliases["get-requirements"] = get_requirements
	aliases["get-all-requirements"] = get_all_requirements
	aliases["recreate-aliases"] = recreate_aliases
	recreate_aliases()

def do_platform_specific_stuff():
	execx($(zoxide init xonsh), 'exec', __xonsh__.ctx, filename='zoxide')
	if $(uname) == "Linux\n":
		# For pipx
		$PATH.append(p"/home/ruhtra/.local/bin")
		source-bash ~/.asdf/asdf.sh
		source-bash ~/.cargo/env
		aliases["pipx"] = "/home/ruhtra/.virtualenvs/pipx/bin/pipx"
	if $(uname) == 'Windows':
		$PATH.append(p'C:/Users/arthu/scoop/persist/rustup-gnu/.cargo/bin')
		aliases["pipx"] = "C:/Users/arthu/.virtualenvs/pipx/Scripts/pipx.exe"
		aliases["font-patcher"] = "fontforge --script ~/AppData/Local/Programs/FontPatcher/font-patcher -c"
		aliases["ligaturizer"] = "fontforge --lang py --script ~/AppData/Local/Programs/Ligaturizer/ligaturize.py --output-dir=~/Fonts --prefix=Liga"
		# execx($(oh-my-posh init xonsh --config C:\Users\arthu\AppData\Local\Programs\oh-my-posh\themes\catppuccin_latte.omp.json))

def load_xontribs():
	xontrib load vox
	xontrib load autovox
	xontrib load coreutils
	xontrib load gitinfo
	xontrib load prompt_starship

def set_env_vars():
	$XONSH_COLOR_STYLE = "catppuccin-mocha"
	$VIRUALENV_HOME = "~/.virtualenvs"
	$PROMPT = "{CYAN}{env_name}{BLUE}{user}@{hostname} {DEFAULT}{localtime} {branch_color}{curr_branch:{}@}{cwd} {gitstatus}\n{DEFAULT}{RED}[{last_return_code}] {GREEN}{prompt_end} "

# @events.on_pre_prompt
# def make_venv_importable():
# 	try:
# 		path = str(Path($VIRTUAL_ENV) / 'lib' / 'python3.12' / 'site-packages')
# 		if path not in sys.path:
# 			$VIRTUAL_ENV_OLD = $VIRTUAL_ENV
# 			sys.path.insert(0, path)
# 	except KeyError:
# 		pass
# 	if 'VIRTUAL_ENV_OLD' in ${...}:
# 		if ('VIRTUAL_ENV' in ${...} and $VIRTUAL_ENV != $VIRTUAL_ENV_OLD) or ('VIRTUAL_ENV' not in ${...}):
# 			for i, path in enumerate(sys.path[:]):
# 				if $VIRTUAL_ENV_OLD in path:
# 					del sys.path[i]

def install_rich():
	from rich import pretty
	from rich import traceback
	pretty.install()
	traceback.install(show_locals=True)
	del pretty
	del traceback

def main():
	set_env_vars()
	load_xontribs()
	do_platform_specific_stuff()
	install_rich()
	create_aliases()

main()





