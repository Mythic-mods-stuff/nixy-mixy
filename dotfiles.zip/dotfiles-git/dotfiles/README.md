# My dotfiles
This repo contains the dotfiles for my NixOS systems.

## (Re-)Installation process
- Boot the generic NixOS installer image (ideally the graphical one)
- Run the installation script (with the respective options) and follow its steps afterward:
  ```bash
  sudo nix --experimental-features "nix-command flakes" run git+https://iris.radicle.xyz/z3rXb1szZKawTSNj3KMHUydTyDBXR#nectarine-gardener -- plant
```
